# Added a new npm package: qs
Stringify the query parameter for the token api call
# Run npm init to install this package
# Added Utils.js inside common to make the api calls before the component is rendered
 Handled multiple api call's for features, releases in parallel as yo avoid slow execution, we can send all the API calls at once and execute them in parallel. As a result, there is no particular order in which the calls finish their execution, but their execution times do not add up since they run together.Calls are made inside useEffect() hook where the dependencies are also defined.
# Handling of api for the component which is not in the browser view is done through a custom hook. Hook is added (../Spotify/react-coding-challenges/spootify/src/routes/Discover/components/Hooks/hook.js)
 <Discover >component which needs api response is wrapped inside a new component <BrowseCatgories). Browse categories is not in the viewport view , when the page is loaded, so rather than making an api call on load, as soon as the third component is in viewport which is handled through custom hook 'useElementOnScreen'.  Api call is made inside <BroseCategories> component inside useEffect hook and data is fetched. To detect the component in viewport inside the hook, IntersectionObserver has been used. Initally the  component is hidden by setting inital state varibale to false and make it true when it is inside the viewport
 Also class based approach has been changed to function based approach, using hooks along.

# Security
For securing config files,  .env is one of best practice, as the boilerplate, as storing anywhere else in JS file will  be bundled and could be read clientside. Other ways could be to handle config files on server , where config can be different for different environments and can also be accessed by application. Also cloud can be used to host the config files and provides security.

