import React, { useEffect, useState, useRef } from 'react';
import DiscoverBlock from './DiscoverBlock/components/DiscoverBlock';
import { fetchApiData, getAuth } from '../../../common/Utils'
import BrowseCategories from './BrowseCategories';
import {useElementOnScreen} from './Hooks/hook'

import '../styles/_discover.scss';

function Discover() {
  const [newReleases, setNewReleases] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [token, setToken] = useState(null);
 // const [showCategories, setShowCategories] = useState(false);
 // const containerRef =useRef(null);
 // const [isVisible, setIsVisible] = useState(false);

  function setMusicData(data, pathParam) {
    switch (pathParam) {
      case 'new-releases':
        setNewReleases(data.albums.items);
        break;
      case 'featured-playlists':
        setPlaylists(data.playlists.items);
        break;
      default:
        break;
    }
  }

  useEffect(() => {
    const getToken = async () => {
      try {
        const data = await getAuth();
        setToken(data);
      } catch (e) {
        console.error(e);
      }
    };

    if (!token) {
      getToken();
    }
  }, [token]);

  useEffect(() => {
    const fetchMusicCategories = async (pathParam) => {
      try {
        const data = await fetchApiData(pathParam, token);
        setMusicData(data, pathParam);
      } catch (e) {
        console.error(e);
      }
    };

    if (token) {
      fetchMusicCategories('new-releases');
      fetchMusicCategories('featured-playlists');
    }

  }, [token]);
  
  
  const [ containerRef, isVisible ] = useElementOnScreen({
      root: null,
      rootMargin: "0px",
      threshold:1.0
    })
  
 

  return (
    <div className="discover">
      <DiscoverBlock text="RELEASED THIS WEEK" id="released" data={newReleases} />
      <DiscoverBlock text="FEATURED PLAYLISTS" id="featured" data={playlists} />
      <div ref={containerRef}>
       {isVisible && <BrowseCategories token={token} /> }
      </div>
    </div>
  );
}

export default Discover;