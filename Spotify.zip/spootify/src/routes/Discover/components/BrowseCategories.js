import React, { useEffect, useState } from 'react';
import DiscoverBlock from './DiscoverBlock/components/DiscoverBlock';
import {fetchApiData} from '../../../common/Utils'

function BrowseCategories({token}){
    const [categories, setCategories] = useState([]);
    
      useEffect(() => {
        const pathParam ='categories'
        const fetchMusicCategories = async (pathParam) => {
          try {
            const data = await fetchApiData(pathParam, token);
            setCategories(data.categories.items);
          } catch (e) {
            console.error(e);
          }
        };
    
        if (token) {
          fetchMusicCategories(pathParam);
        }
    
      }, [token]);

      return (
        <DiscoverBlock  text="BROWSE" id="browse" data={categories} imagesKey="icons" />
      )
}

export default BrowseCategories