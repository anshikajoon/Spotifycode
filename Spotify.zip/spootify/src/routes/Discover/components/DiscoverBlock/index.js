export { default } from './components/DiscoverBlock';
