import axios from 'axios'
import qs from 'qs';
import API from '../config'

export const fetchApiData = async(pathParam, token) => {
  const baseUrl = API.baseUrl;
  const headers = {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Bearer ${token}`
    }
  };

  try {
    const response = await axios.get(
      `${baseUrl}${pathParam}`,
      headers
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
}

export const getAuth = async () => {
  const clientId = API.clientId
  const clientSecret = API.clientSecret;

  const headers = {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    auth: {
      username: clientId,
      password: clientSecret,
    },
  };
  const data = {
    grant_type: 'client_credentials',
  };

  try {
    const response = await axios.post(
      API.authUrl,
       qs.stringify(data),
      headers
    );
    return response.data.access_token;
  } catch (error) {
      console.log(error);
  }
};