export { default } from './components/App';
