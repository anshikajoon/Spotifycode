import Home from './App';

// Use something like react-router-dom to manage multiple pages/routes

export default Home;
