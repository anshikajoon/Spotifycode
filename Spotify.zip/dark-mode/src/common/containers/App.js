import React from 'react';

export default function App({ children }) {
  return children;
}
