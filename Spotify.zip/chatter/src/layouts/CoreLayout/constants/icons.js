export default [
  { name: 'far fa-circle', maxSize: 40 },
  { name: 'fas fa-circle', minSize: 7, maxSize: 10 },
  { name: 'far fa-star', maxSize: 40 },
  { name: 'fas fa-square', minSize: 7, maxSize: 10 },
  { name: 'far fa-square', maxSize: 40 },
  { name: 'mdi mdi-message-outline', minSize: 20, maxSize: 40, noRotation: true },
  { name: 'mdi mdi-triangle-wave', minSize: 20, maxSize: 40 },
  { name: 'mdi mdi-hexagon-outline', maxSize: 40 },
  { name: 'mdi mdi-triangle-outline', minSize: 20, maxSize: 40 }
];
