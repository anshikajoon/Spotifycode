export { default } from './components/CoreLayout';
