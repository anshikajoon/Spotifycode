import React from 'react';
import CoreLayout from './layouts/CoreLayout';

export default function App() {
  return (
    <CoreLayout />
  );
}
