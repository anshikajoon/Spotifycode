import INITIAL_BOTTY_MESSAGE from '../../../common/constants/initialBottyMessage';

export default  {
  bot: INITIAL_BOTTY_MESSAGE,
  brandon: 'Hello there!',
  clayton: 'Yes of course. Thanks',
  bernice: 'This is a question regarding the fun time we had.',
  christine: 'Do you need help with the price?',
  mike: 'Choose the perfect accommodation',
  callie: 'Yes thanks!',
  herbert: 'Of course, send as an email to my address.',
  bessie: 'Sorry you couldn\'t read it',
  lottie: '728 Feeney Street.',
  augusta: 'I got the transfer! :D'
};
