export default 'Hi! My name\'s Botty.';
