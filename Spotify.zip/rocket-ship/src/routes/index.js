import LaunchPad from './LaunchPad';

// Use something like react-router-dom to manage multiple pages/routes

export default LaunchPad;
